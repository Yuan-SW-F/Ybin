package MCseq;
use strict qw(subs ref);
use feature qw(say);
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(reseq);

sub resep
{
	
}
