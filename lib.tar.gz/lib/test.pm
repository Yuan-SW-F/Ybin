package test;
use strict qw(subs refs);
use feature qw(say);
use lib '/home/st_agric/lib';
use agric;
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(test path);
sub test
{
}
__END__
