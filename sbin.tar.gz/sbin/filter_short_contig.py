#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Author: fuyuan (907569282@qq.com)
# Created Time: 2019-09-12 11:17:49
# Example filter_short_contig.py   
import sys, os, re

fp = open(sys.argv[1])
pre = sys.argv[2]
cut = 1000
if len(sys.argv) == 4:
	cut = sys.argv[3]

os.system('faSize -detailed ' + sys.argv[1] + ' > ' + sys.argv[2] + '.sizes')

leng = {}
fp = open(sys.argv[2] + '.sizes')
for line in fp:
	line = line.strip()
	list = line.split()
	leng[list[0]] = int(list[1])

fp = open(sys.argv[1])
check = 0
ft = open(sys.argv[2], 'w')
for line in fp:
	re_id = re.match('>(\S+)', line)
	if re_id:
		if leng[re_id.group(1)] >= cut:
			check = 1
		else:
			check = 0
	if check == 1:
		ft.write(line)
