#!/public/agis/chengshifeng_group/fuyuan/pip-fuyuan/app/anaconda2/bin/python
# -*- coding: UTF-8 -*-
# Author: fuyuan (907569282@qq.com)
# Created Time: 2019-05-16 12:24:04
# Example time.py   
import sys, os, re

t1 = sys.argv[1]
t2 = sys.argv[2]

def times(time):
	list = re.split(':',time)
	my_time = 0
	if len(list) == 3:
			my_time += 24*60*int(list[0])
			my_time += 60*int(list[1])
			my_time +=    int(list[2])
	return my_time

my_t1 = times(t1)
my_t2 = times(t2)

my_t = (my_t2-my_t1)*100/60*0.01
print '\t' + str(my_t) + ' hours'
