#!/bin/bash
# File Name: meme.sh
# Author  : fuyuan, 907569282@qq.com
# Created Time: 2019-08-23 13:41:34
source ~/.bashrc

O=`echo $1 | perl -ne 'print \$1 if /([^\.]+)/'`
H=`echo $1 | perl -ne 'print \$1 if /([^\.\/]+)[^\/]+$/'`
S=$2
if [ ! $S ];then
	S="Motif"
	fi
meme -dna -nostatus -time 18000 -mod zoops -nmotifs 10 -minw 6 -maxw 50 -revcomp -markov_order 0 -o $O $1
grep -P "MOTIF.*MEME"  $O/meme.txt | perl -ne 's/\s+\=\s+/\=/g;@l=split;print join "\t","$2.$1.$l[2]",@l[1,3..$#l];print "\n" ' > $O/MOTIF.xls
less $O/MOTIF.xls | sed s/../$S.$H./ > $O/MOTIF.xlsx
mv $O/MOTIF.xlsx $O/MOTIF.xls
