#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Author: fuyuan (907569282@qq.com)
# Created Time: 2019-08-23 09:28:03
# Example split_fasta.py   
import sys, os, re

file = sys.argv[1]
fp = open(file)
cut = 500000000
if len(sys.argv) == 3:
	cut = sys.argv[2]
count = 1
length = 0
for line in fp:
	re_id = re.match('>', line)
	if re_id:
		if length >= cut*(count-1):
			ft = open(file + '_' + str(count), 'w')
			count += 1
	else:
		length += len(line) - 1
	ft.write(line)
