#!/bin/bash
# File Name: Q.sh
# Author  : fuyuan, 907569282@qq.com
# Created Time: 2019-04-18 16:14:53
source ~/.bashrc
ls */*sh  | awk -F "/" '{print "cd "$1";QS 1 1 "$2";cd -"}' 
