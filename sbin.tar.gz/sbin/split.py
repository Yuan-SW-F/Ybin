#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Author: fuyuan (907569282@qq.com)
# Created Time: 2019-08-27 14:44:12
# Example split.py   
import sys, os, re

fp = os.popen('gunzip -c ' +sys.argv[1])

count = 101
cut = 0
for line in fp:
	re_head = re.match('0', line)
	if re_head:
		count += 1
	if count > 100:
		cut += 1
		ft = open('cut_' + str(cut) + ".axt", 'w')
		count = 0
	line = re.sub(r'DD_\d+\.','',line)
	ft.write(line)
ft.close()


