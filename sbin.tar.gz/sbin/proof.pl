#!/usr/bin/perl -w
=head1 Name
    /ifs1/ST_PLANT/USER/fuyuan/Program/Bin/bin/proof.pl
Info
    Author: fuyuan, fuyuan@genomics.cn
    Created Time: 2017-01-13 16:52:30
    Created Version: proof.pl
	changed from /ifs1/ST_PLANT/USER/changyue/Program/wwl-commonBin/annotation/maker/accessroy/proof.pl (changyue)
Usage
    proof.pl	compelete.gff maker_raw.gff
=cut
use strict;
use feature qw(say);
use lib '/hwfssz1/ST_AGRIC/LOCAL/Pipline/PL-program/lib';
#'/ifs1/ST_PLANT/USER/fuyuan/Program/Bin/MCPM';
use MCsub;
use Getopt::Long;
my ($help);
GetOptions(
	"help!"=>\$help
);
die opth() if $help;

my $gff=shift;
my $target=shift;

open SH1,">s01cat.sh";
print SH1 "cat $gff\|grep -P \"\\taugustus\\t\" >$gff.augustus\ncat $gff\|grep -P \"\\tgenemark\\t\" >$gff.genemark\ncat $gff\|grep -P \"\\tsnap\\t\" >$gff.snap\ncat $gff\|grep -P \"\\tblastx\\t\" >$gff.blastx\ncat $gff\|grep -P \"\\tprotein2genome\\t\" >$gff.protein2genome\ncat $gff\|grep -P \"\\ttblastx\\t\" >$gff.tblastx\ncat $gff\|grep -P \"\\tcdna2genome\\t\" >$gff.cdna2genome\ncat $gff\|grep -P \"\\test2genome\\t\" >$gff.est2genome\ncat $gff\|grep -P \"\\tblastn\\t\" >$gff.blastn\n";
close SH1;

open SH2,">s02proof00.sh";
print SH2 "perl /ifs1/ST_PLANT/USER/changyue/Program/wwl-commonBin/annotation/maker/accessroy/stat_gene_evidence.pl -glean $target -predict $gff.augustus -predict $gff.genemark -predict $gff.snap -homolog $gff.blastx -homolog $gff.protein2genome -homolog $gff.tblastx -cdna $gff.cdna2genome -cdna $gff.est2genome -cdna $gff.blastn\n";
close SH2;

open SH3,">s02proof02.sh";
print SH3 "perl /ifs1/ST_PLANT/USER/changyue/Program/wwl-commonBin/annotation/maker/accessroy/stat_gene_evidence.pl --cutoff 0.2 -glean $target -predict $gff.augustus -predict $gff.genemark -predict $gff.snap -homolog $gff.blastx -homolog $gff.protein2genome -homolog $gff.tblastx -cdna $gff.cdna2genome -cdna $gff.est2genome -cdna $gff.blastn\n";
close SH3;

open SH4, ">s02proof05.sh";
print SH4 "perl /ifs1/ST_PLANT/USER/changyue/Program/wwl-commonBin/annotation/maker/accessroy/stat_gene_evidence.pl --cutoff 0.5 -glean $target -predict $gff.augustus -predict $gff.genemark -predict $gff.snap -homolog $gff.blastx -homolog $gff.protein2genome -homolog $gff.tblastx -cdna $gff.cdna2genome -cdna $gff.est2genome -cdna $gff.blastn\n";
close SH4;

open SH5, ">s03clean.sh";
print SH5 "rm $gff.augustus $gff.genemark $gff.snap $gff.blastx $gff.protein2genome $gff.tblastx $gff.cdna2genome $gff.est2genome $gff.blastn\n";

