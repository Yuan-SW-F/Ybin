export PATH="/public/agis/chengshifeng_group/fuyuan/conda2/bin:$PATH"
/public/agis/chengshifeng_group/fuyuan/pip-fuyuan/software/busco-master/scripts/run_BUSCO.py -i  -o bus_species_geno__embryophyta -l /public/agis/chengshifeng_group/fuyuan/pip-fuyuan/database/busco/Eukaryota/embryophyta_odb9 -m geno -c 30 -f 
