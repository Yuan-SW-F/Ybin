#!/usr/bin/perl -w
=head1 Name
    /szhwfs1/ST_AGRIC/DIGITAL/F13ZHQYJSY1409/USER/fuyuan/Nitrogen/Discaria_trinervis/04.annotation/02.maker/Discaria_trinervis_v1.0.fa.9/check.pl
Info
    Author: fuyuan, fuyuan@genomics.cn
    Created Time: 2016-12-30 10:22:07
    Created Version: check.pl
Usage
    check.pl	
=cut
use strict;
use feature qw(say);
use lib '/hwfssz1/ST_AGRIC/LOCAL/Pipline/PL-program/lib';
use Getopt::Long;
my ($help);
GetOptions(
	"help!"=>\$help
);
die opth() if $help;

open F12,"finished.list";
my ($id,$seq,$len);
while (<F12>){
	`less $_`=~/cd\s+(\S+)\/([^\s\/\;]+)/;
	my $file=$1 if `ls $1/../*cut/$2` =~/(\S+)/;
	say $file;
	open F11,"$file";
	while (<F11>){
		$id=$1 if /\>?(\S+)/;
		$/="\>";
		$seq=<F11>;
		$seq=~s/\>$//;
		$seq=~s/\s//g;
		$len+=length($seq);
		$/="\n";
		}
	}
say $len;
