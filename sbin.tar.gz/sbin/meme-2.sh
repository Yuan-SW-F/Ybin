#!/bin/bash
# File Name: meme.sh
# Author  : fuyuan, 907569282@qq.com
# Created Time: 2019-08-23 13:41:34
source ~/.bashrc

O=`echo $1 | perl -ne 'print \$1 if /([^\.]+)/'`
#H=`echo $1 | perl -ne 'print \$1 if /([^\.\/]+)[^\/]+$/'`
H=`echo $1 | perl -ne 'print \$1."-".\$2 if /([^\/]+)\/([^\.\/]+)[^\/]+$/'`
S=$2
grep -P "MOTIF.*MEME"  $O/meme.txt | perl -ne 's/\s+\=\s+/\=/g;@l=split;print join "\t","$2.$1.$l[2]",@l[1,3..$#l];print "\n" ' > $O/MOTIF.xls
less $O/MOTIF.xls | sed s/../$S.$H./ > $O/MOTIF.xlsx
mv $O/MOTIF.xlsx $O/MOTIF.xls
