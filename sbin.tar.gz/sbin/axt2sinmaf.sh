#!/bin/bash
# File Name: axt2sinmaf.sh
# Author  : fuyuan, 907569282@qq.com
# Created Time: 2019-08-27 15:19:50
source ~/.bashrc

P=$1
R=$2
Q=$3
axtSort $P $P.sorted.axt
#axtBest -minOutSize=200 -minScore=10000 $P.sorted.axt all $P.sorted.best.axt
ln -s $P.sorted.axt $P.sorted.best.axt
axtChain -linearGap=/public/agis/chengshifeng_group/fuyuan/pip-fuyuan/GAP_matrix_plant.dms $P.sorted.best.axt $R.2bit $Q.2bit $P.sorted.best.filtered.chain
chainPreNet $P.sorted.best.filtered.chain $R.sizes $Q.sizes $P.sorted.best.filtered.pre.chain
chainNet $P.sorted.best.filtered.pre.chain -minSpace=1 $R.sizes $Q.sizes stdout /dev/null | netSyntenic stdin $P.sorted.best.filtered.pre.noClass.net
ln -s $P.sorted.best.filtered.pre.noClass.net $P.net
netToAxt $P.net $P.sorted.best.filtered.pre.chain $R.2bit $Q.2bit stdout | axtSort stdin $P.net.sorted.axt
axtToMaf $P.net.sorted.axt $R.sizes $Q.sizes $P.net.sorted.axt.maf
echo "less $P.net.sorted.axt.maf | perl -ne 'if (/^a/){print \$_;\$i=<STDIN>;\$i=~s/^s\\ /s\\ $R\./;\$j=<STDIN>;\$j=~s/^s\\ /s\\ $Q\./;print \$i.\$j;}else{print \$_;}' > $P.maf" |sh
maf_sort $P.maf $R > $P.orig.maf
single_cov2 $P.orig.maf R=$R > $P.sing.maf
